# This is not a real Python file
# It is here only to fool Cython into believing
# that the pyx file is part of a package (which
# it is), as otherwise, the module name
# will be wrong
